#ifndef _GETWIIFILEDEVICE_H_
#define _GETWIIFILEDEVICE_H_
#include "filesystems.h"
enum STORAGE_DEVICES getWiiFileDevice(const char *strFilename);
#endif
