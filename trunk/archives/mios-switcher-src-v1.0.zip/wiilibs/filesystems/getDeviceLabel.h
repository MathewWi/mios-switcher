#ifndef _GETDEVICELABEL_H_
#define _GETDEVICELABEL_H_
#include "filesystems.h"
const char *getDeviceLabel(enum STORAGE_DEVICES STORAGE_DEVICE);
#endif
