#ifndef _UNMOUNTFATDEVICE_H_
#define _UNMOUNTFATDEVICE_H_
void unmountFatDevice();
#endif
