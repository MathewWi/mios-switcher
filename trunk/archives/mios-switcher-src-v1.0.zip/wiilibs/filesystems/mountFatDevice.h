#ifndef _MOUNTFATDEVICE_H_
#define _MOUNTFATDEVICE_H_
#include "filesystems.h"
enum STORAGE_DEVICES mountFatDevice(unsigned char chStorageDevicesCount,...);
#endif
