#ifndef _MOUNTNANDFS_H_
#define _MOUNTNANDFS_H_
#include <stdbool.h>
bool mountNandFs();
#endif
