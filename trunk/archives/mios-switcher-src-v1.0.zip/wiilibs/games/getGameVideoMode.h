#ifndef _GETGAMEVIDEOMODE_H_
#define _GETGAMEVIDEOMODE_H_
#include <ogc/gx_struct.h>
#include "../video/video.h"
GXRModeObj *getGameVideoMode(const char *strDiscID,enum VIDEO_MODES *VIDEO_MODE);
#endif
