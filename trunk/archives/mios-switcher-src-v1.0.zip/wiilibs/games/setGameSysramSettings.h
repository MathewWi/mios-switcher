#ifndef _SETGAMESYSRAMSETTINGS_H_
#define _SETGAMESYSRAMSETTINGS_H_
#include <gctypes.h>
#include "games.h"
u32 setGameSysramSettings(struct stGameConfig *stGamesSettings);
#endif
