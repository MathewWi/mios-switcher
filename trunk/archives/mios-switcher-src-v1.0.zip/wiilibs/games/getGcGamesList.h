#ifndef _GETGCGAMESLIST_H_
#define _GETGCGAMESLIST_H_
#include "../dvd/dvd.h"
struct stDvdDiscInfos *getGcGamesList(unsigned int *intGamesCount,unsigned char chDevicesCount,...);
#endif
