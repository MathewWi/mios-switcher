#ifndef _SETGAMEVIDEOSETTINGS_H_
#define _SETGAMEVIDEOSETTINGS_H_
#include "../video/video.h"
#include "games.h"
void setGameVideoSettings(struct stGameConfig *stGameSettings,enum VIDEO_MODES VIDEO_MODE);
#endif
