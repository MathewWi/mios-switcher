#ifndef _SETGAMESYSTEMSETTINGS_H_
#define _SETGAMESYSTEMSETTINGS_H_
#include "games.h"
void setGameSystemSettings(struct stGameConfig *stGamesSettings);
#endif
