#ifndef _GETBGCOLORPATTERN_H_
#define _GETBGCOLORPATTERN_H_
#include "video.h"
char *getBgColorPattern(enum CONSOLE_FONT_COLORS FONT_COLOR);
#endif
