#ifndef _CLEARCONSOLE_H_
#define _CLEARCONSOLE_H_
void clearConsole();
#endif
