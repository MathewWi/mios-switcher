#ifndef _RESETDEFAULTFONTSTYLE_H_
#define _RESETDEFAULTFONTSTYLE_H_
void resetDefaultFontStyle();
#endif
