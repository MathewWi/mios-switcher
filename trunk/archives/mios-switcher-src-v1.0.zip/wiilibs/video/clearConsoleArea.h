#ifndef _CLEARCONSOLEAREA_H_
#define _CLEARCONSOLEAREA_H_
#include <gctypes.h>
void clearConsoleArea(u8 intRow,u8 intColumn,u8 intRowsCount,u8 intColumnsCount);
#endif
