#ifndef _GETFGCOLORPATTERN_H_
#define _GETFGCOLORPATTERN_H_
#include "video.h"
char *getFgColorPattern(enum CONSOLE_FONT_COLORS FONT_COLOR,enum CONSOLE_FONT_WEIGHTS FONT_WEIGHT);
#endif
