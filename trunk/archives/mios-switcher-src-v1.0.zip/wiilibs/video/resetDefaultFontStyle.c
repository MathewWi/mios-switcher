#include "../../main.h"
#include "setFontStyle.h"
//version finale
void resetDefaultFontStyle() {
    setFontStyle(DEFAULT_FONT_BGCOLOR,DEFAULT_FONT_FGCOLOR,DEFAULT_FONT_WEIGHT);
}
