#ifndef _GETCONSOLEROW_H_
#define _GETCONSOLEROW_H_
int getConsoleRow();
#endif
