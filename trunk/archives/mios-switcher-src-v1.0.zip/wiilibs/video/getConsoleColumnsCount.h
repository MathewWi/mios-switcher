#ifndef _GETCONSOLECOLUMNSCOUNT_H_
#define _GETCONSOLECOLUMNSCOUNT_H_
int getConsoleColumnsCount();
#endif
