#ifndef _GETCONSOLECOLUMN_H_
#define _GETCONSOLECOLUMN_H_
int getConsoleColumn();
#endif
