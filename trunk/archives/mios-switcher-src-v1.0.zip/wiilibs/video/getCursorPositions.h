#ifndef _GETCURSORPOSITIONS_H_
#define _GETCURSORPOSITIONS_H_
void getCursorPositions(int *intColumn,int *intRow);
#endif
