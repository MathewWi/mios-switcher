#ifndef _GETPADSKEYLABELS_H_
#define _GETPADSKEYLABELS_H_
#include <gctypes.h>
unsigned char getPadsKeyLabels(s32 intMappedPadKey,char **strPadsKeyLabels);
#endif
