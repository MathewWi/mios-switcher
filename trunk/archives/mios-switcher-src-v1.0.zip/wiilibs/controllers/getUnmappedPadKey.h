#ifndef _GETUNMAPPEDPADKEY_H_
#define _GETUNMAPPEDPADKEY_H_
#include <gctypes.h>
#include "controllers.h"
s32 getUnmappedPadKey(s32 intMappedPadKey,enum CONTROLLERS CONTROLLER);
#endif
