#ifndef _GETPADSKEYPRESSED_H_
#define _GETPADSKEYPRESSED_H_
#include <gctypes.h>
s32 getPadsKeyPressed(s32 *intExpectedPadsKeysPressed,unsigned int intExpectedPadsKeysCount,bool blnMappedPadsKey,unsigned short int intScanPadsTime,s32 intTimeoutPadsKey);
#endif
