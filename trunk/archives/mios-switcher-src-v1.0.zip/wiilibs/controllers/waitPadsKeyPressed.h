#ifndef _WAITPADSKEYPRESSED_H_
#define _WAITPADSKEYPRESSED_H_
#include <gctypes.h>
s32 waitPadsKeyPressed(const char *strMessage,unsigned short int intWaitingTime);
#endif
