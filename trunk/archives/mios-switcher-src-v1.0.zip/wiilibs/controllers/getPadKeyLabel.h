#ifndef _GETPADKEYLABEL_H_
#define _GETPADKEYLABEL_H_
#include <gctypes.h>
#include "controllers.h"
char *getPadKeyLabel(s32 intPadKey,enum CONTROLLERS CONTROLLER);
#endif
