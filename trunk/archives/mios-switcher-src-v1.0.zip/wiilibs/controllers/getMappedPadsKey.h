#ifndef _GETMAPPEDPADSKEY_H_
#define _GETMAPPEDPADSKEY_H_
#include <gctypes.h>
s32 getMappedPadsKey(s32 intPadsKey);
#endif
