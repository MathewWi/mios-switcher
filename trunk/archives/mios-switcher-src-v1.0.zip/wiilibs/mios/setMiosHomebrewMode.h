#ifndef _SETMIOSHOMEBREWMODE_H_
#define _SETMIOSHOMEBREWMODE_H_
#include <stddef.h>
#include <gctypes.h>
void setMiosHomebrewMode(const u8 *chMiosDolBooter,size_t intMiosDolBooterSize,const u8 *chGcDol,size_t intGcDolSize);
#endif
