#ifndef _ACTIVATEMIOS_H_
#define _ACTIVATEMIOS_H_
#include <stdbool.h>
bool activateMios(unsigned char chSelectedMios);
#endif
