#ifndef _MOVEMIOSNANDITEMS_H_
#define _MOVEMIOSNANDITEMS_H_
#include <stdbool.h>
bool moveMiosNandItems(unsigned char chDestMiosIndex);
#endif
