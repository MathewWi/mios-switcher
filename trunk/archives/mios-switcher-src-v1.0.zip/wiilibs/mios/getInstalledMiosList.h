#ifndef _GETINSTALLEDMIOSLIST_H_
#define _GETINSTALLEDMIOSLIST_H_
#include "../menu/menu.h"
#include "../titles/titles.h"
struct stListItem *getInstalledMiosList(struct stTitleInfos **stInstalledMiosInfos,unsigned char chInstalledMiosCount);
#endif
