#ifndef _GETINSTALLEDMIOSINFOS_H_
#define _GETINSTALLEDMIOSINFOS_H_
#include "../titles/titles.h"
struct stTitleInfos **getInstalledMiosInfos(unsigned char *chInstalledMiosCount,struct stTitleInfos *stKnownMiosInfos,unsigned int intKnownMiosCount);
#endif
