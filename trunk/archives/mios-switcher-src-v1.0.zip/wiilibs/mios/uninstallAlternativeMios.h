#ifndef _UNINSTALLALTERNATIVEMIOS_H_
#define _UNINSTALLALTERNATIVEMIOS_H_
#include <stdbool.h>
#include "../titles/titles.h"
bool uninstallAlternativeMios(unsigned char chSelectedMios,struct stTitleInfos **stInstalledMiosInfos,unsigned char *chInstalledMiosCount);
#endif
