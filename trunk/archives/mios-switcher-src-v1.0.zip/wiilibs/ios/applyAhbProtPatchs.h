#ifndef _APPLYAHBPROTPATCHS_H_
#define _APPLYAHBPROTPATCHS_H_
unsigned int applyAhbProtPatchs();
#endif
