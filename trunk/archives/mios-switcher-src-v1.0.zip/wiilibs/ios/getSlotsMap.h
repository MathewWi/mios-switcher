#ifndef _GETSLOTSMAP_H_
#define _GETSLOTSMAP_H_
#include "ios.h"
struct stSlotInfos *getSlotsMap();
#endif
