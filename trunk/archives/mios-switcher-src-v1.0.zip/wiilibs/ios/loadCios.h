#ifndef _LOADCIOS_H_
#define _LOADCIOS_H_
#include <gctypes.h>
void loadCios(bool blnTryAhbProt,u8 chDefaultCios);
#endif
