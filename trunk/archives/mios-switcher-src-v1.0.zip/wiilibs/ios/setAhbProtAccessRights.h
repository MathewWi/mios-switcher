#ifndef _SETAHBPROTACCESSRIGHTS_H_
#define _SETAHBPROTACCESSRIGHTS_H_
unsigned int setAhbProtAccessRights();
#endif
