#ifndef _INITDVD_H_
#define _INITDVD_H_
#include <stdbool.h>
bool initDvd();
#endif
