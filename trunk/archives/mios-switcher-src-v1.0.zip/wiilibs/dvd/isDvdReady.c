#include "isDvdReady.h"
extern bool isDVDReady;
bool isDvdReady() {
    return isDVDReady;
}
