#ifndef _STOPDVD_H_
#define _STOPDVD_H_
void stopDvd();
#endif
