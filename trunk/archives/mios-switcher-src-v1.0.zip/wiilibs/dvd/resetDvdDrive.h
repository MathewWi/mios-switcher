#ifndef _RESETDVDDRIVE_H_
#define _RESETDVDDRIVE_H_
void resetDvdDrive();
#endif
