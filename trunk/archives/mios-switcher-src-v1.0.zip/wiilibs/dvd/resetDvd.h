#ifndef _RESETDVD_H_
#define _RESETDVD_H_
#include <stdbool.h>
bool resetDvd();
#endif
