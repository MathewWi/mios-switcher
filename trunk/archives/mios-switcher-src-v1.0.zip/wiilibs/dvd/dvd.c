#include <gctypes.h>
s32 intDiFd;
bool isDVDReady=false;
