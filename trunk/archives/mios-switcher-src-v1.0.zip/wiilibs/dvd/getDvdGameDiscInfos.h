#ifndef _GETDVDGAMEDISCINFOS_H_
#define _GETDVDGAMEDISCINFOS_H_
#include "dvd.h"
struct stDvdDiscInfos *getDvdGameDiscInfos();
#endif
