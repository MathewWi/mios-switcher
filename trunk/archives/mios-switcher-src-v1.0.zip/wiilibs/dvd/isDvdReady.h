#ifndef _ISDVDREADY_H_
#define _ISDVDREADY_H_
#include <stdbool.h>
bool isDvdReady();
#endif
