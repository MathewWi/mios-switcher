#ifndef _GETDVDDRIVEINFOS_H_
#define _GETDVDDRIVEINFOS_H_
#include <ogc/dvd.h>
dvddrvinfo *getDvdDriveInfos();
#endif
