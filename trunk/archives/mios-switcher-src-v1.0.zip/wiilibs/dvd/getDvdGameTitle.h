#ifndef _GETDVDGAMETITLE_H_
#define _GETDVDGAMETITLE_H_
char *getDvdGameTitle();
#endif
