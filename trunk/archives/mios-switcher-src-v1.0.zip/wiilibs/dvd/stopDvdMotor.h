#ifndef _STOPDVDMOTOR_H_
#define _STOPDVDMOTOR_H_
#include <stdbool.h>
bool stopDvdMotor();
#endif
