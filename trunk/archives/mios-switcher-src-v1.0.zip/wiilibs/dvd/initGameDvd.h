#ifndef _INITGAMEDVD_H_
#define _INITGAMEDVD_H_
#include <ogc/dvd.h>
dvddiskid *initGameDvd();
#endif
