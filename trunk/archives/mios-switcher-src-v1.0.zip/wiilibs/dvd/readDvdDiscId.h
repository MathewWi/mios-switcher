#ifndef _READDVDDISCID_H_
#define _READDVDDISCID_H_
#include <ogc/dvd.h>
dvddiskid *readDvdDiscId();
#endif
