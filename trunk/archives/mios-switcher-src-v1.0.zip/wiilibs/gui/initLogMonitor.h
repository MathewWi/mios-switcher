#ifndef _INITLOGMONITOR_H_
#define _INITLOGMONITOR_H_
#include <gctypes.h>
#include "gui.h"
void initLogMonitor(u8 chRow,u8 chColumn,u8 chRowsCount,u8 chColumnsCount,bool blnClear,struct stLogMonitor *stLogMonitorSettings);
#endif
