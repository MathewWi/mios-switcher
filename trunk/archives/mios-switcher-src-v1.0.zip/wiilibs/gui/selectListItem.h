#ifndef _SELECTLISTITEM_H_
#define _SELECTLISTITEM_H_
#include "gui.h"
void selectListItem(struct stGuiList *stListSettings,unsigned int intSelectedListItemIndex);
#endif
