#ifndef _INITMENUITEMS_H_
#define _INITMENUITEMS_H_
#include "../gui/gui.h"
void initMenuItems(struct stLabel *stLabelsSettings,unsigned char chMenuItemsCount);
#endif
