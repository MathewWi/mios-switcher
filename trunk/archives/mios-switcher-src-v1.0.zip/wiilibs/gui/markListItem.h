#ifndef _MARKLISTITEM_H_
#define _MARKLISTITEM_H_
#include "../video/video.h"
#include "gui.h"
void markListItem(struct stGuiList *stListSettings,unsigned int intSelectedListItemIndex,char chMarkChar,enum CONSOLE_FONT_COLORS FONT_COLOR);
#endif
