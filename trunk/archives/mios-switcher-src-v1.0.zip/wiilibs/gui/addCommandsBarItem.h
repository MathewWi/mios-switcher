#ifndef _ADDCOMMANDSBARITEM_H_
#define _ADDCOMMANDSBARITEM_H_
#include <gctypes.h>
#include "gui.h"
void addCommandsBarItem(struct stCommandsBar *stCommandsBarSettings,s32 *intMappedPadKeys,unsigned char chMappedPadKeysCount,const char *strCommandText);
#endif
