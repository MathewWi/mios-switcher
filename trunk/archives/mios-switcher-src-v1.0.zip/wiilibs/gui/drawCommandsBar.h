#ifndef _DRAWCOMMANDSBAR_H_
#define _DRAWCOMMANDSBAR_H_
#include <stdbool.h>
#include "gui.h"
void drawCommandsBar(unsigned char chCommandsCount,bool blnStatusBar,struct stCommandsBar *stCommandsBarSettings);
#endif
