#ifndef _GETTEXTBOXROW_H_
#define _GETTEXTBOXROW_H_
#include <gctypes.h>
u8 getTextBoxRow(u8 chRow);
#endif
