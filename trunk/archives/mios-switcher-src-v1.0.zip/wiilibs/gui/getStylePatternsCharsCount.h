#ifndef _GETSTYLEPATTERNSCHARSCOUNT_H_
#define _GETSTYLEPATTERNSCHARSCOUNT_H_
#include <stddef.h>
size_t getStylePatternsCharsCount(const char *strText);
#endif
