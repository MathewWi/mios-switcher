#ifndef _DESTROYLIST_H_
#define _DESTROYLIST_H_
#include <stdbool.h>
#include "gui.h"
void destroyList(struct stGuiList *stListSettings,bool blnClearList);
#endif
