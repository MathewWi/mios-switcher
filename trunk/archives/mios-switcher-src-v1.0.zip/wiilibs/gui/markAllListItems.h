#ifndef _MARKALLLISTITEMS_H_
#define _MARKALLLISTITEMS_H_
#include "../video/video.h"
#include "gui.h"
void markAllListItems(struct stGuiList *stListSettings,char chMarkChar,enum CONSOLE_FONT_COLORS FONT_COLOR);
#endif
