#ifndef _GETTEXTBOXCOLUMN_H_
#define _GETTEXTBOXCOLUMN_H_
#include <gctypes.h>
u8 getTextBoxColumn(u8 chColumn);
#endif
