#ifndef _ONRESETBUTTONDOWN_H_
#define _ONRESETBUTTONDOWN_H_
void onResetButtonDown();
#endif
