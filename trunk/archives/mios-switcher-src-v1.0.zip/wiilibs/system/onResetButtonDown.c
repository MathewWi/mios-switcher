#include <stdbool.h>
//version finale
extern bool blnUserResetRequest;
void onResetButtonDown() {
    blnUserResetRequest=true;
}
