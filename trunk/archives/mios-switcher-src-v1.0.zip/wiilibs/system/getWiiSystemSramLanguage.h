#ifndef _GETWIISYSTEMSRAMLANGUAGE_H_
#define _GETWIISYSTEMSRAMLANGUAGE_H_
#include "system.h"
enum SRAM_GC_LANGUAGES getWiiSystemSramLanguage();
#endif
