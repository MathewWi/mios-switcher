#include "getUserResetRequestStatus.h"
//version finale
extern bool blnUserResetRequest;
bool getUserResetRequestStatus() {
    return blnUserResetRequest;
}
