#ifndef _SETCACHECODESEGMENT_H_
#define _SETCACHECODESEGMENT_H_
#include <stddef.h>
void setCacheCodeSegment(void *varCacheCodeSegment,size_t intCodeSegmentSize,void *varNewCode);
#endif
