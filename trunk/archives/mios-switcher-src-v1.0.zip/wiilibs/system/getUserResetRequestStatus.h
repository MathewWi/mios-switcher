#ifndef _GETUSERRESETREQUESTSTATUS_H_
#define _GETUSERRESETREQUESTSTATUS_H_
#include <stdbool.h>
bool getUserResetRequestStatus();
#endif
