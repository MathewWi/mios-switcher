#ifndef _INITCACHECODESEGMENT_H_
#define _INITCACHECODESEGMENT_H_
#include <stddef.h>
void initCacheCodeSegment(void *varCacheCodeSegment,size_t intCodeSegmentSize,unsigned char chInitValue);
#endif
