#ifndef _INITCACHEDATASEGMENT_H_
#define _INITCACHEDATASEGMENT_H_
#include <stddef.h>
void initCacheDataSegment(void *varCacheDataSegment,size_t intDataSegmentSize,unsigned char chInitValue);
#endif
