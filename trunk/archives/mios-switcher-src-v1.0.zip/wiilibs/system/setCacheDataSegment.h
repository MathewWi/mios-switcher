#ifndef _SETCACHEDATASEGMENT_H_
#define _SETCACHEDATASEGMENT_H_
#include <stddef.h>
void setCacheDataSegment(void *varCacheDataSegment,size_t intDataSegmentSize,void *varNewData);
#endif
