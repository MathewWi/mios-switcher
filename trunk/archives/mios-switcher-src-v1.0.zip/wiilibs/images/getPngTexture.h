#ifndef _GETPNGTEXTURE_H_
#define _GETPNGTEXTURE_H_
#include <stdbool.h>
#include "images.h"
bool getPngTexture(const void *imgData,struct stPngTexture *stTexture);
#endif
