#ifndef _GETPNGIMAGERESSOURCE_H_
#define _GETPNGIMAGERESSOURCE_H_
#include "../../clibs/libshare/pngu.h"
IMGCTX getPngImageRessource(const void *imgData,PNGUPROP *imgProperties);
#endif
