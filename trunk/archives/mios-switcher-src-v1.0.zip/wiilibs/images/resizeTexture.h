#ifndef _RESIZETEXTURE_H_
#define _RESIZETEXTURE_H_
void *resizeTexture(void **imgRGBAData,unsigned int intWidth,unsigned int intHeight,unsigned int intNewWidth,unsigned int intNewHeight);
#endif
