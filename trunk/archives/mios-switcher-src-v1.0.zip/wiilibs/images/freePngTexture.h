#ifndef _FREEPNGTEXTURE_H_
#define _FREEPNGTEXTURE_H_
#include "images.h"
void freePngTexture(struct stPngTexture *stTexture);
#endif
