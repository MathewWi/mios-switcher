#ifndef _GETTILETEXTURE_H_
#define _GETTILETEXTURE_H_
void *getTileTexture(const void *imgRGBAData,unsigned int intWidth,unsigned int intHeight,unsigned int intTileLeft,unsigned int intTileTop,unsigned int *intTileWidth,unsigned int *intTileHeight);
#endif
