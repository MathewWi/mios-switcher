#ifndef _CREATENANDFOLDER_H_
#define _CREATENANDFOLDER_H_
#include <gctypes.h>
s32 createNandFolder(const char *strFolderPath);
#endif
