#ifndef _ISNANDDIRECTORY_H_
#define _ISNANDDIRECTORY_H_
#include <stdbool.h>
bool isNandDirectory(const char *strDirectoryPath);
#endif
