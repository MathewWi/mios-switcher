#include <stdbool.h>
#include "nand.h"
bool haveNANDAccess=false;
char strNandPath[NAND_PATH_MAXLENGTH];
