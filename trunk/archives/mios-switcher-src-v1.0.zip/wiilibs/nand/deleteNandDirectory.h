#ifndef _DELETENANDDIRECTORY_H_
#define _DELETENANDDIRECTORY_H_
#include <gctypes.h>
s32 deleteNandDirectory(const char *strDirectoryPath);
#endif
