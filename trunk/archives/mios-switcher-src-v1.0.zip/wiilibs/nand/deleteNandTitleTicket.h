#ifndef _DELETENANDTITLETICKET_H_
#define _DELETENANDTITLETICKET_H_
#include <gctypes.h>
s32 deleteNandTitleTicket(u64 intTitleId);
#endif
