#ifndef _DELETENANDTITLEFOLDER_H_
#define _DELETENANDTITLEFOLDER_H_
#include <gctypes.h>
s32 deleteNandTitleFolder(u64 intTitleId);
#endif
