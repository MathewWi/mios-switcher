#ifndef _EXISTNANDFILE_H_
#define _EXISTNANDFILE_H_
#include <stdbool.h>
bool existNandFile(const char *strFileName);
#endif
