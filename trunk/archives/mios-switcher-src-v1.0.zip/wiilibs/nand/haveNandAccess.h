#ifndef _HAVENANDACCESS_H_
#define _HAVENANDACCESS_H_
#include <stdbool.h>
bool haveNandAccess();
#endif
