#ifndef _DELETENANDFILE_H_
#define _DELETENANDFILE_H_
#include <gctypes.h>
s32 deleteNandFile(const char *strFileName);
#endif
