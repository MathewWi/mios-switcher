#ifndef _RENAMENANDFOLDER_H_
#define _RENAMENANDFOLDER_H_
#include <gctypes.h>
s32 renameNandFolder(const char *strFolderPath,const char *strNewFolderName);
#endif
