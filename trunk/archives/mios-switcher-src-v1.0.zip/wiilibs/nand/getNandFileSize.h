#ifndef _GETNANDFILESIZE_H_
#define _GETNANDFILESIZE_H_
#include <gctypes.h>
s32 getNandFileSize(s32 intFd);
#endif
