#ifndef _EXISTNANDTITLE_H_
#define _EXISTNANDTITLE_H_
#include <gctypes.h>
bool existNandTitle(u64 intTitleId);
#endif
