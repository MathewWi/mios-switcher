#ifndef _GETNANDFILECONTENT_H_
#define _GETNANDFILECONTENT_H_
#include <stddef.h>
void *getNandFileContent(const char *strNandFileName,size_t *intNandFileSize);
#endif
