#ifndef _DELETENANDDIRECTORYCONTENT_H_
#define _DELETENANDDIRECTORYCONTENT_H_
#include <gctypes.h>
s32 deleteNandDirectoryContent(const char *strDirectoryPath);
#endif
