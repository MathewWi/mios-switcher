#ifndef _MOVENANDFOLDERCONTENT_H_
#define _MOVENANDFOLDERCONTENT_H_
#include <gctypes.h>
s32 moveNandFolderContent(const char *strSrcFolderPath,const char *strDestFolderPath);
#endif
