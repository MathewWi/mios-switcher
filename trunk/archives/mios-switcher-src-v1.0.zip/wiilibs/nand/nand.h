#ifndef _NAND_H_
#define _NAND_H_
#include <ogc/ipc.h>
#include <ogc/isfs.h>
enum {
    NAND_PATH_MAXLENGTH=ISFS_MAXPATH+1
};
#endif
