#ifndef _UNINSTALLTITLE_H_
#define _UNINSTALLTITLE_H_
#include <gctypes.h>
s32 uninstallTitle(u64 intTitleId,bool blnSafeMode);
#endif
