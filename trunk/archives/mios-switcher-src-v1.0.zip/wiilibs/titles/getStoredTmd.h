#ifndef _GETSTOREDTMD_H_
#define _GETSTOREDTMD_H_
#include <gctypes.h>
#include <ogc/es.h>
signed_blob *getStoredTmd(u64 intTitleId,u32 *intTmdSize);
#endif
