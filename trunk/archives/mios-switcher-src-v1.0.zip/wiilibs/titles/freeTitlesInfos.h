#ifndef _FREETITLESINFOS_H_
#define _FREETITLESINFOS_H_
#include "titles.h"
void freeTitlesInfos(struct stTitleInfos **stTitlesInfos,unsigned int intTitlesCount);
#endif
