#ifndef _EXISTTITLE_H_
#define _EXISTTITLE_H_
#include <gctypes.h>
bool existTitle(u64 intTitleId);
#endif
