#ifndef _GETNEXTFREETITLEID_H_
#define _GETNEXTFREETITLEID_H_
#include <gctypes.h>
u64 getNextFreeTitleId(u64 intStartTitleId);
#endif
