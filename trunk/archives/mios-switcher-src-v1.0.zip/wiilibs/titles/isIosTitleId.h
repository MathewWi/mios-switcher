#ifndef _ISIOSTITLEID_H_
#define _ISIOSTITLEID_H_
#include <gctypes.h>
bool isIosTitleId(u64 intTitleId);
#endif
