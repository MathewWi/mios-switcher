#ifndef _DELETETITLETICKET_H_
#define _DELETETITLETICKET_H_
#include <gctypes.h>
s32 deleteTitleTicket(u64 intTitleId);
#endif
