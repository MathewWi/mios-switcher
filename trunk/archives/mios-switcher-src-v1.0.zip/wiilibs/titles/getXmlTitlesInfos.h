#ifndef _GETXMLTITLESINFOS_H_
#define _GETXMLTITLESINFOS_H_
#include "titles.h"
struct stTitleInfos *getXmlTitlesInfos(const char *strXmlTitlesInfos,unsigned int *intTitlesCount);
#endif
