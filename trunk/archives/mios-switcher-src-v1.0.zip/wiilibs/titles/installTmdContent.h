#ifndef _INSTALLTMDCONTENT_H_
#define _INSTALLTMDCONTENT_H_
#include <gctypes.h>
s32 installTmdContent(u64 intTitleId,u32 intTmdContentId,u8 *chContentBuffer,u32 intContentSize);
#endif
