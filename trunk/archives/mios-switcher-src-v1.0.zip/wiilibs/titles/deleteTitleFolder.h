#ifndef _DELETETITLEFOLDER_H_
#define _DELETETITLEFOLDER_H_
#include <gctypes.h>
s32 deleteTitleFolder(u64 intTitleId);
#endif
