#ifndef _GETTITLES_H_
#define _GETTITLES_H_
#include <gctypes.h>
u64 *getTitles(u32 *intTitlesCount);
#endif
