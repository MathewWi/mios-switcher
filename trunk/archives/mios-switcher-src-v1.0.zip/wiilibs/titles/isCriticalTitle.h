#ifndef _ISCRITICALTITLE_H_
#define _ISCRITICALTITLE_H_
#include <gctypes.h>
bool isCriticalTitle(u64 intTitleId);
#endif
