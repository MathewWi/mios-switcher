#ifndef _FREELISTITEMS_H_
#define _FREELISTITEMS_H_
#include "menu.h"
void freeListItems(struct stListItem **stListItems,unsigned int intListItemsCount);
#endif
