#ifndef _GETLISTITEMID_H_
#define _GETLISTITEMID_H_
int getListItemId(unsigned int intCurrentItemId,int intMoveStep,unsigned int intListItemsCount);
#endif
