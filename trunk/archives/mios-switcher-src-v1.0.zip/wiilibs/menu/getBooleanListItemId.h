#ifndef _GETBOOLEANLISTITEMID_H_
#define _GETBOOLEANLISTITEMID_H_
unsigned char getBooleanListItemId(unsigned int *intBooleanOptionsSetting,int intBooleanOption,signed char chMoveStep);
#endif
