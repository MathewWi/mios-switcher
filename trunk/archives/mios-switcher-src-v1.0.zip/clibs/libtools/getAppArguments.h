#ifndef _GETAPPARGUMENTS_H_
#define _GETAPPARGUMENTS_H_
#include "libtools.h"
unsigned int getAppArguments(char **strAppArguments,unsigned int intAppArgumentsCount,struct stAppArgument *stAppArguments,unsigned int intScanArgumentsCount);
#endif
