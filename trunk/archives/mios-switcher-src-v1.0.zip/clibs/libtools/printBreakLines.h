#ifndef _PRINTBREAKLINES_H_
#define _PRINTBREAKLINES_H_
#include <stddef.h>
unsigned int printBreakLines(char chBreakChar,size_t intMaxLineSize,const char *strText);
#endif
