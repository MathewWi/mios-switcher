#ifndef _GETFORMATTEDSTRING_H_
#define _GETFORMATTEDSTRING_H_
char *getFormattedString(char *strFormattedString,const char *strFormat,...);
#endif
