#ifndef _PRINTREPEATSTRING_H_
#define _PRINTREPEATSTRING_H_
unsigned int printRepeatString(unsigned int intRepeatsCount,const char *strFormatValue,...);
#endif
