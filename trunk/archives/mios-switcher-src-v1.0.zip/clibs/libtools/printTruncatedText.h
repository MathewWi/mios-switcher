#ifndef _PRINTTRUNCATEDTEXT_H_
#define _PRINTTRUNCATEDTEXT_H_
#include <stddef.h>
int printTruncatedText(const char *strOverflowString,size_t intTruncateSize,const char *strText);
#endif
