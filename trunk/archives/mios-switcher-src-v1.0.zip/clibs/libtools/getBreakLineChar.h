#ifndef _GETBREAKLINECHAR_H_
#define _GETBREAKLINECHAR_H_
#include <stddef.h>
char *getBreakLineChar(const char *strValue,char chBreakChar,size_t intMaxLineSize);
#endif
