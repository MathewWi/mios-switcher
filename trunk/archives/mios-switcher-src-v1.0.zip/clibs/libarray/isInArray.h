#ifndef _ISINARRAY_H_
#define _ISINARRAY_H_
#include <stdbool.h>
bool isInArray(const void *varItems,unsigned int intItemsCount,int intItemSize,const void *varItem,bool blnSorted);
#endif
