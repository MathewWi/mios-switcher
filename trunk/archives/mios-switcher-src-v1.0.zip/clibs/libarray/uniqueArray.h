#ifndef _UNIQUEARRAY_H_
#define _UNIQUEARRAY_H_
#include <stddef.h>
unsigned int uniqueArray(const void *varArray,size_t intItemSize,unsigned int intItemsCount,unsigned int intOffsetUniqueField,int intUniqueFieldSize);
#endif
