#ifndef _GETARRAYITEMINDEX_H_
#define _GETARRAYITEMINDEX_H_
#include <stdbool.h>
unsigned int getArrayItemIndex(const void *varItems,unsigned int intItemsCount,int intItemSize,const void *varItem,bool blnSorted);
#endif
