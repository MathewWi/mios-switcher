#ifndef _PRINTJOINEDARRAYSTRINGITEMS_H_
#define _PRINTJOINEDARRAYSTRINGITEMS_H_
unsigned int printJoinedArrayStringItems(const char **strItems,unsigned int *intItemsIndexes,unsigned int intItemsCount,const char *strBeforeItem,const char *strSeparator,const char *strAfterItem,const char *strJoin);
#endif
