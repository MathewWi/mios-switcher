#ifndef _ISINSTRINGARRAY_H_
#define _ISINSTRINGARRAY_H_
#include <stdbool.h>
bool isInStringArray(const char *strValue,const char **strArray,unsigned int intArraySize);
#endif
