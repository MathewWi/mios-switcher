#ifndef _GETARRAYMAXMEMORYITEMINDEX_H_
#define _GETARRAYMAXMEMORYITEMINDEX_H_
unsigned int getArrayMaxMemoryItemIndex(const void *varMemoryItems,unsigned int intMemoryItemsCount,int intItemSize,unsigned int intMemoryStepSize);
#endif
