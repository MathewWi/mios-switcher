#ifndef _PRINTJOINEDARRAYSTRINGMEMORYITEMS_H_
#define _PRINTJOINEDARRAYSTRINGMEMORYITEMS_H_
unsigned int printJoinedArrayStringMemoryItems(const char **strMemoryItems,unsigned int *intMemoryItemsIndexes,unsigned int intMemoryItemsCount,unsigned int intMemoryStepSize,const char *strBeforeItem,const char *strSeparator,const char *strAfterItem,const char *strJoin);
#endif
