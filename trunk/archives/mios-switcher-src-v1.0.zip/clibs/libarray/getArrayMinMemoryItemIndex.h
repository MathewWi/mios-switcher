#ifndef _GETARRAYMINMEMORYITEMINDEX_H_
#define _GETARRAYMINMEMORYITEMINDEX_H_
unsigned int getArrayMinMemoryItemIndex(const void *varMemoryItems,unsigned int intMemoryItemsCount,int intItemSize,unsigned int intMemoryStepSize);
#endif
