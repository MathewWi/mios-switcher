#ifndef _GETARRAYMAXITEMINDEX_H_
#define _GETARRAYMAXITEMINDEX_H_
unsigned int getArrayMaxItemIndex(const void *varItems,unsigned int intItemsCount,int intItemSize);
#endif
