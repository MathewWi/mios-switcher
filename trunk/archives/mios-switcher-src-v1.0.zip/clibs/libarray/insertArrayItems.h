#ifndef _INSERTARRAYITEMS_H_
#define _INSERTARRAYITEMS_H_
#include <stddef.h>
unsigned int insertArrayItems(void **varItems,unsigned int *intItemsCount,unsigned int intInsertIndex,size_t intItemSize,int intInsertedItemsCount,...);
#endif
