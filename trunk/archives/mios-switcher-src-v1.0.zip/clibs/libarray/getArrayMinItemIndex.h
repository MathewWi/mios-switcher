#ifndef _GETARRAYMINITEMINDEX_H_
#define _GETARRAYMINITEMINDEX_H_
unsigned int getArrayMinItemIndex(const void *varItems,unsigned int intItemsCount,int intItemSize);
#endif
