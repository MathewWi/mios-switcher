#ifndef _UNIQUESTRINGARRAY_H_
#define _UNIQUESTRINGARRAY_H_
unsigned int uniqueStringArray(char **strArray,unsigned int intArraySize);
#endif
