#ifndef _GETBREAKSTRINGS_H_
#define _GETBREAKSTRINGS_H_
#include <stddef.h>
char **getBreakStrings(const char *strValue,char chBreakChar,size_t intMaxLineSize,unsigned int *intBreakStringsCount);
#endif
