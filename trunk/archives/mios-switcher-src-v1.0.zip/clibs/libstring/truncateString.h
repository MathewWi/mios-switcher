#ifndef _TRUNCATESTRING_H_
#define _TRUNCATESTRING_H_
#include <stddef.h>
char *truncateString(const char *strOverflowString,size_t intTruncateSize,char *strText);
#endif
