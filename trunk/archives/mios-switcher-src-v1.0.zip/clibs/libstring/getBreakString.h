#ifndef _GETBREAKSTRING_H_
#define _GETBREAKSTRING_H_
#include <stddef.h>
char *getBreakString(const char *strValue,char chBreakChar,size_t intMaxStringSize);
#endif
