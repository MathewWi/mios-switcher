#ifndef _GETSPLITSTRINGS_H_
#define _GETSPLITSTRINGS_H_
char **getSplitStrings(const char *strValue,const char *strSeparator,unsigned int *intItemsCount);
#endif
