#ifndef _GETDEBUGMESSAGESOURCELINENUMBER_H_
#define _GETDEBUGMESSAGESOURCELINENUMBER_H_
unsigned int getDebugMessageSourceLineNumber(unsigned char chDebugMessageIndex);
#endif
