#ifndef _GETDEBUGMESSAGECODE_H_
#define _GETDEBUGMESSAGECODE_H_
int getDebugMessageCode(unsigned char chDebugMessageIndex);
#endif
