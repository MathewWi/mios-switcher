#ifndef _GETDEBUGMESSAGETYPE_H_
#define _GETDEBUGMESSAGETYPE_H_
#include "libdebug.h"
enum LOG_MESSAGES getDebugMessageType(unsigned char chDebugMessageIndex);
#endif
