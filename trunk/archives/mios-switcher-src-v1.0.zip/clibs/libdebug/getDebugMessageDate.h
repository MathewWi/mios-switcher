#ifndef _GETDEBUGMESSAGEDATE_H_
#define _GETDEBUGMESSAGEDATE_H_
#include <time.h>
time_t *getDebugMessageDate(unsigned char chDebugMessageIndex);
#endif
