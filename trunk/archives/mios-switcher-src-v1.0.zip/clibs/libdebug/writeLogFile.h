#ifndef _WRITELOGFILE_H_
#define _WRITELOGFILE_H_
void writeLogFile(const char *strFileName,int intLogMessageFilter);
#endif
