#ifndef _GETDEBUGMESSAGE_H_
#define _GETDEBUGMESSAGE_H_
char *getDebugMessage(unsigned char chDebugMessageIndex);
#endif
