#ifndef _ISINRANGE_H_
#define _ISINRANGE_H_
#include <stdbool.h>
signed char isInRange(double dbValue,double dbMinRangeValue,double dbMaxRangeValue,bool blnIncludeMinRange,bool blnIncludeMaxRange);
#endif
