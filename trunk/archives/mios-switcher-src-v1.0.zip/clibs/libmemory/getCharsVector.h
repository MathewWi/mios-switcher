#ifndef _GETCHARSVECTOR_H_
#define _GETCHARSVECTOR_H_
#include <stddef.h>
char *getCharsVector(size_t intSizeVect,unsigned int intInitOffset,size_t intInitSize,char chInitValue);
#endif
