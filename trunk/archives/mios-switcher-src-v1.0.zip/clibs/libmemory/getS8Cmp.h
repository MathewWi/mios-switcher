#ifndef _GETS8CMP_H_
#define _GETS8CMP_H_
#include <stddef.h>
int getS8Cmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
