#ifndef _SETS16ITEM_H_
#define _SETS16ITEM_H_
#include <stddef.h>
void *setS16Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
