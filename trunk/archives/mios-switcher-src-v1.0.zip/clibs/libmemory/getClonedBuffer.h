#ifndef _GETCLONEDBUFFER_H_
#define _GETCLONEDBUFFER_H_
#include <stddef.h>
void *getClonedBuffer(void *chBuffer,size_t intBufferSize,size_t intBlockSize);
#endif
