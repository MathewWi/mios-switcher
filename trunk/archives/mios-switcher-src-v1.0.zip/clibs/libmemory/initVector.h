#ifndef _INITVECTOR_H_
#define _INITVECTOR_H_
#include <stddef.h>
void *initVector(void **varVector,unsigned int intItemsCount,size_t intItemSize,const void *varInitItem);
#endif
