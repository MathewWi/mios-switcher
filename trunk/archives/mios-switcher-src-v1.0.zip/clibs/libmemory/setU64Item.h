#ifndef _SETU64ITEM_H_
#define _SETU64ITEM_H_
#include <stddef.h>
void *setU64Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
