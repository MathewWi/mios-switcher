#ifndef _GETALIGNEDDYNAMICMEMORY_H_
#define _GETALIGNEDDYNAMICMEMORY_H_
#include <stddef.h>
void *getAlignedDynamicMemory(size_t intMemorySize,size_t intBlockSize);
#endif
