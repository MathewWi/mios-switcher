#ifndef _REALLOCBUFFER_H_
#define _REALLOCBUFFER_H_
#include <stddef.h>
void *reallocBuffer(void **varBuffer,size_t intBufferSize,size_t intBlockSize);
#endif
