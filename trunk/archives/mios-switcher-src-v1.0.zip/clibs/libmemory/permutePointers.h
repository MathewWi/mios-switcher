#ifndef _PERMUTEPOINTERS_H_
#define _PERMUTEPOINTERS_H_
void permutePointers(void **varPointer1,void **varPointer2);
#endif
