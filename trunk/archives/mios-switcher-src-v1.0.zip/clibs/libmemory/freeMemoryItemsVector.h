#ifndef _FREEMEMORYITEMSVECTOR_H_
#define _FREEMEMORYITEMSVECTOR_H_
#include <stddef.h>
void freeMemoryItemsVector(void **varVector,unsigned int intVectorItemsCount,size_t intMemoryStepSize);
#endif
