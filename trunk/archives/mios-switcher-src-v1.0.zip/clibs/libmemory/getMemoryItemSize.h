#ifndef _GETMEMORYITEMSIZE_H_
#define _GETMEMORYITEMSIZE_H_
#include <stddef.h>
size_t getMemoryItemSize(int intItemSize);
#endif
