#ifndef _SWAPMEMORY_H_
#define _SWAPMEMORY_H_
#include <stddef.h>
void **swapMemory(void *varMemory0,void *varMemory1,size_t intMemorySize);
#endif
