#ifndef _GETDYNAMICMEMORY_H_
#define _GETDYNAMICMEMORY_H_
#include <stddef.h>
void *getDynamicMemory(size_t intMemorySize);
#endif
