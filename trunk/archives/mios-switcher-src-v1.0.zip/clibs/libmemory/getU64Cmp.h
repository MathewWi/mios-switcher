#ifndef _GETU64CMP_H_
#define _GETU64CMP_H_
#include <stddef.h>
int getU64Cmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
