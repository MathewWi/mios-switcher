#ifndef _SETDOUBLEITEM_H_
#define _SETDOUBLEITEM_H_
#include <stddef.h>
void *setDoubleItem(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
