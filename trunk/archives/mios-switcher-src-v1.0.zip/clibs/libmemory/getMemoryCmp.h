#ifndef _GETMEMORYCMP_H_
#define _GETMEMORYCMP_H_
#include <stddef.h>
int getMemoryCmp(const void *varMemory1,const void *varMemory2,size_t intMemorySize);
#endif
