#ifndef _FREERECURSIVEVECTOR_H_
#define _FREERECURSIVEVECTOR_H_
void freeRecursiveVector(void ***varVector,unsigned int intVectorItemsCount);
#endif
