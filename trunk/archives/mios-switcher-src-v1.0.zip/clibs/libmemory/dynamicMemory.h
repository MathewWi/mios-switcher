#ifndef _DYNAMICMEMORY_H_
#define _DYNAMICMEMORY_H_
#include <stddef.h>
void *dynamicMemory(void **varMemory,size_t intMemorySize,size_t intBlockSize);
#endif
