#ifndef _SETU32ITEM_H_
#define _SETU32ITEM_H_
#include <stddef.h>
void *setU32Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
