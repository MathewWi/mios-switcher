#ifndef _GETMEMORYITEM_H_
#define _GETMEMORYITEM_H_
void *getMemoryItem(const void *varMemoryItems,unsigned int intItemIndex,unsigned int intMemoryStepSize);
#endif
