#ifndef _FREEMEMORYITEMSVECTORS_H_
#define _FREEMEMORYITEMSVECTORS_H_
#include <stddef.h>
void freeMemoryItemsVectors(size_t intVectorItemsCount,size_t intMemoryStepSize,unsigned int intVectorsCount,...);
#endif
