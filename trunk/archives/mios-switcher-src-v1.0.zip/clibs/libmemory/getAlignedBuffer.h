#ifndef _GETALIGNEDBUFFER_H_
#define _GETALIGNEDBUFFER_H_
#include <stddef.h>
void *getAlignedBuffer(size_t intBufferSize,size_t intBlockSize);
#endif
