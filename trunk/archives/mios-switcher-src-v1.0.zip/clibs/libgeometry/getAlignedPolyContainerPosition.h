#ifndef _GETALIGNEDPOLYCONTAINERPOSITION_H_
#define _GETALIGNEDPOLYCONTAINERPOSITION_H_
#include "libgeometry.h"
double getAlignedPolyContainerPosition(const double *dbPolyPointsPositions,unsigned int intPointsCount,double dbContainerMinPosition,double dbContainerMaxPosition,enum ALIGNEMENTS ALIGNEMENT);
#endif
