#ifndef _GETPOLYCONTAINERPOSITION_H_
#define _GETPOLYCONTAINERPOSITION_H_
double getPolyContainerPosition(const double *dbPolyPointsPositions,unsigned int intPointsCount,double dbContainerMinPosition,double dbContainerMaxPosition,double dbPositionType);
#endif
