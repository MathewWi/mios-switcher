#ifndef _ISEXPIREDTIMER_H_
#define _ISEXPIREDTIMER_H_
#include <stdbool.h>
#include "libtime.h"
bool isExpiredTimer(struct stTimer *stTimerSettings);
#endif
