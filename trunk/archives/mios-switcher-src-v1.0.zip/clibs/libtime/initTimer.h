#ifndef _INITTIMER_H_
#define _INITTIMER_H_
#include "libtime.h"
void initTimer(struct stTimer *stTimerSettings,unsigned short int intTimerInterval);
#endif
