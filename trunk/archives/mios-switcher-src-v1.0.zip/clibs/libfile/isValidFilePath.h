#ifndef _ISVALIDFILEPATH_H_
#define _ISVALIDFILEPATH_H_
#include <stdbool.h>
bool isValidFilePath(const char *strFilePath);
#endif
