#ifndef _GETFILESIZE2_H_
#define _GETFILESIZE2_H_
#include <stdio.h>
long getFileSize2(FILE *fp);
#endif
