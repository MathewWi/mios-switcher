#ifndef _GETDEVICENAME_H_
#define _GETDEVICENAME_H_
char *getDeviceName(const char *strFilename);
#endif
