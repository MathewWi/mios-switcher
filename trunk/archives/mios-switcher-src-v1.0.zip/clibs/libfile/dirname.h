#ifndef _DIRNAME_H_
#define _DIRNAME_H_
char *dirname(char *strFileName);
#endif
