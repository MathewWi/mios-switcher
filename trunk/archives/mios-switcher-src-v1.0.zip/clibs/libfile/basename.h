#ifndef _BASENAME_H_
#define _BASENAME_H_
char *basename(const char *strFileName);
#endif
