#ifndef _ISDIRECTORY_H_
#define _ISDIRECTORY_H_
#include <stdbool.h>
bool isDirectory(const char *strDirectory);
#endif
