#ifndef _DEVICENAME_H_
#define _DEVICENAME_H_
char *devicename(char *strPath);
#endif
