#ifndef _GETFILESIZE_H_
#define _GETFILESIZE_H_
long getFileSize(const char *strFileName);
#endif
