#ifndef _GETFILENAMEEXTENSION_H_
#define _GETFILENAMEEXTENSION_H_
char *getFilenameExtension(const char *strFilename);
#endif
