#ifndef _WRITEBINARYFILE_H_
#define _WRITEBINARYFILE_H_
#include <stddef.h>
void writeBinaryFile(const char *strFileName,const void *varContent,size_t intContentSize);
#endif
