#ifndef _ISVALIDFILENAME_H_
#define _ISVALIDFILENAME_H_
#include <stdbool.h>
bool isValidFileName(const char *strFileName,char **chInvalidChar);
#endif
