#ifndef _MAIN_H_
#define _MAIN_H_
#include "wiilibs/video/video.h"
#define GUI_BACKGROUND_COLOR CONSOLE_BLACK
#define DEFAULT_FONT_BGCOLOR CONSOLE_FONT_BLACK
#define DEFAULT_FONT_FGCOLOR CONSOLE_FONT_WHITE
#define DEFAULT_FONT_WEIGHT CONSOLE_FONT_NORMAL
#define VERSION "1.0"
//#define DEBUG_FILE "mios-switcher.log"
#endif
