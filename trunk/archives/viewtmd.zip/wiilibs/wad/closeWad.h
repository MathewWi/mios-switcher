#ifndef _CLOSEWAD_H_
#define _CLOSEWAD_H_
#include <stdio.h>
#include "wad.h"
void closeWad(FILE *fpwad,struct stWadMap *stWadFileMap);
#endif
