#ifndef _SETWADFILEMAPHEADER_H_
#define _SETWADFILEMAPHEADER_H_
#include <stdbool.h>
#include "wad.h"
bool setWadFileMapHeader(struct stWadHeader *stWadTitleHeader,struct stWadMap *stWadFileMap);
#endif
