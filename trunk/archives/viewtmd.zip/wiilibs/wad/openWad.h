#ifndef _OPENWAD_H_
#define _OPENWAD_H_
#include <stdio.h>
#include "wad.h"
FILE *openWad(const char *strWadFileName,struct stWadMap *stWadFileMap);
#endif
