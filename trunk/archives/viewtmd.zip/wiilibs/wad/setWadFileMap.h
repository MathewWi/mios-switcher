#ifndef _SETWADFILEMAP_H_
#define _SETWADFILEMAP_H_
#include <stdbool.h>
#include <stdio.h>
#include "wad.h"
bool setWadFileMap(FILE *fpwad,struct stWadMap *stWadFileMap);
#endif
