#ifndef _ISWAD_H_
#define _ISWAD_H_
#include <stdbool.h>
bool isWad(void *chWadBuffer);
#endif
