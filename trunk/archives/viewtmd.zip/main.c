#include <stdio.h>
#include <stddef.h>
#include "clibs/libcryptography/getBufferSha1.h"
#include "clibs/libmemory/freeVector.h"
#include "clibs/libdebug/showLogMessage.h"
#include "clibs/libdebug/libdebug.h"
#include "clibs/libfile/getFileContent.h"
#include "clibs/libwii/libwii.h"
#include "clibs/libtools/showBufferHexDump.h"
#include "clibs/libtools/swapBytes.h"
#include "clibs/ctypes.h"
#include "clibs/macros.h"
#include "wiilibs/wad/openWad.h"
#include "wiilibs/wad/getWadFileData.h"
#include "wiilibs/wad/closeWad.h"
#include "wiilibs/wad/wad.h"
signed_blob *getSignedTmd(const char *strInputFileName,size_t *intTmdSize) {
signed_blob *varout=NULL;
FILE *fpWad;
struct stWadMap stWadFileMap;
    if ((fpWad=openWad(strInputFileName,&stWadFileMap))!=NULL) {
        varout=getWadFileData(fpWad,&stWadFileMap,WAD_TMD_DATA,intTmdSize,0);
        closeWad(fpWad,&stWadFileMap);
    }
    else {
        if ((varout=getFileContent(strInputFileName,intTmdSize,0))!=NULL) {
            if (!IS_VALID_SIGNATURE(varout)) {
                freeVector((void **) &varout);
            }
        }
    }
    return varout;
}
int main(int intArgumentsCount,char *strArguments[]) {
signed_blob *sTmd=NULL;
u16 i;
tmd *pTmd;
sha1 tmdHash;
    if (intArgumentsCount==2) {
        if ((sTmd=getSignedTmd(strArguments[1],(size_t *) &intArgumentsCount))==NULL) {
            showLogMessage(ERROR_LOG_MESSAGE,__FILE__,__LINE__,"%s file not found\n",strArguments[1]);
        }
        else {
            pTmd=(tmd *)SIGNATURE_PAYLOAD(sTmd);
            if ((void *) pTmd==(void *) sTmd) {
                showLogMessage(ERROR_LOG_MESSAGE,__FILE__,__LINE__,"bad TMD signature\n");
            }
            else {
                fprintf(stdout,"***TMD hashes***\nSigned TMD hash:");
                showBufferHexDump(getBufferSha1(sTmd,intArgumentsCount,tmdHash),sizeof(sha1),false);
                i=pTmd->num_contents;
                intArgumentsCount=*((u16 *) swapBytes((unsigned char *) &i,sizeof(i)))*sizeof(tmd_content);
                fprintf(stdout,"\nTMD hash:");
                showBufferHexDump(getBufferSha1(pTmd,intArgumentsCount+sizeof(tmd),tmdHash),sizeof(sha1),false);
                fprintf(stdout,"\n\n***TMD data***\nIssuer: %s",pTmd->issuer);
                fprintf(stdout,"\nVersion: %u (0x%0*x)",pTmd->version,sizeof(pTmd->version)*2,pTmd->version);
                fprintf(stdout,"\nCa_crl_version: %u (0x%0*x)",pTmd->ca_crl_version,sizeof(pTmd->ca_crl_version)*2,pTmd->ca_crl_version);
                fprintf(stdout,"\nSigner_crl_version: %u (0x%0*x)",pTmd->signer_crl_version,sizeof(pTmd->signer_crl_version)*2,pTmd->signer_crl_version);
                fprintf(stdout,"\nFill2: %u (0x%0*x)",pTmd->fill2,sizeof(pTmd->fill2)*2,pTmd->fill2);
                swapBytes((unsigned char *) &pTmd->sys_version,sizeof(pTmd->sys_version));
                fprintf(stdout,"\nSys_version: %I64u (0x%08x%08x)",pTmd->sys_version,(u32) MAJOR_NUMBER(pTmd->sys_version,u32),(u32) MINOR_NUMBER(pTmd->sys_version,u32));
                swapBytes((unsigned char *) &pTmd->title_id,sizeof(pTmd->title_id));
                fprintf(stdout,"\nTitle_id: %I64u (0x%08x%08x)",pTmd->title_id,(u32) MAJOR_NUMBER(pTmd->title_id,u32),(u32) MINOR_NUMBER(pTmd->title_id,u32));
                swapBytes((unsigned char *) &pTmd->title_type,sizeof(pTmd->title_type));
                fprintf(stdout,"\nTitle_type: %u (0x%0*x)",pTmd->title_type,sizeof(pTmd->title_type)*2,pTmd->title_type);
                swapBytes((unsigned char *) &pTmd->group_id,sizeof(pTmd->group_id));
                fprintf(stdout,"\nGroup_id: %u (0x%0*x)",pTmd->group_id,sizeof(pTmd->group_id)*2,pTmd->group_id);
                swapBytes((unsigned char *) &pTmd->zero,sizeof(pTmd->zero));
                fprintf(stdout,"\nZero: %u (0x%0*x)",pTmd->zero,sizeof(pTmd->zero)*2,pTmd->zero);
                swapBytes((unsigned char *) &pTmd->region,sizeof(pTmd->region));
                fprintf(stdout,"\nRegion: %u (0x%0*x)",pTmd->region,sizeof(pTmd->region)*2,pTmd->region);
                fprintf(stdout,"\nRatings:");
                showBufferHexDump(pTmd->ratings,sizeof(pTmd->ratings),false);
                fprintf(stdout,"\nReserved:");
                showBufferHexDump(pTmd->reserved,sizeof(pTmd->reserved),false);
                fprintf(stdout,"\nIpc_mask:");
                showBufferHexDump(pTmd->ipc_mask,sizeof(pTmd->ipc_mask),false);
                fprintf(stdout,"\nReserved2:");
                showBufferHexDump(pTmd->reserved2,sizeof(pTmd->reserved2),false);
                swapBytes((unsigned char *) &pTmd->access_rights,sizeof(pTmd->access_rights));
                fprintf(stdout,"\nAccess_rights: %u (0x%0*x)",pTmd->access_rights,sizeof(pTmd->access_rights)*2,pTmd->access_rights);
                swapBytes((unsigned char *) &pTmd->title_version,sizeof(pTmd->title_version));
                fprintf(stdout,"\nTitle_version: %u (0x%0*x)",pTmd->title_version,sizeof(pTmd->title_version)*2,pTmd->title_version);
                fprintf(stdout,"\nNum_contents: %u",*((u16 *) swapBytes((unsigned char *) &pTmd->num_contents,sizeof(pTmd->num_contents))));
                swapBytes((unsigned char *) &pTmd->boot_index,sizeof(pTmd->boot_index));
                fprintf(stdout,"\nBoot_index: %u (0x%0*x)",pTmd->boot_index,sizeof(pTmd->boot_index)*2,pTmd->boot_index);
                swapBytes((unsigned char *) &pTmd->fill3,sizeof(pTmd->fill3));
                fprintf(stdout,"\nFill3: %u (0x%0*x)",pTmd->fill3,sizeof(pTmd->fill3)*2,pTmd->fill3);
                fprintf(stdout,"\n\n***TMD contents data***");
                pTmd->title_id=0;
                for (i=0;i<pTmd->num_contents;i++) {
                    swapBytes((unsigned char *) &pTmd->contents[i].index,sizeof(pTmd->contents[i].index));
                    fprintf(stdout,"\nContent index: %u (0x%0*x)",pTmd->contents[i].index,sizeof(pTmd->contents[i].index)*2,pTmd->contents[i].index);
                    swapBytes((unsigned char *) &pTmd->contents[i].cid,sizeof(pTmd->contents[i].cid));
                    fprintf(stdout,", id: %u (0x%0*x)",pTmd->contents[i].cid,sizeof(pTmd->contents[i].cid)*2,pTmd->contents[i].cid);
                    swapBytes((unsigned char *) &pTmd->contents[i].type,sizeof(pTmd->contents[i].type));
                    fprintf(stdout,", type: %u (0x%0*x)",pTmd->contents[i].type,sizeof(pTmd->contents[i].type)*2,pTmd->contents[i].type);
                    pTmd->title_id=pTmd->title_id+*((u64 *) swapBytes((unsigned char *) &pTmd->contents[i].size,sizeof(pTmd->contents[i].size)));
                    fprintf(stdout,", size: %I64u bytes, hash:",pTmd->contents[i].size);
                    showBufferHexDump(pTmd->contents[i].hash,sizeof(sha1),false);
                }
                fprintf(stdout,"\nTotal contents size: %I64u bytes\nTMD contents hash:",pTmd->title_id);
                showBufferHexDump(getBufferSha1(pTmd->contents,intArgumentsCount,tmdHash),sizeof(sha1),false);
            }
            freeVector((void **) &sTmd);
        }
    }
    else {
        fprintf(stdout,"USAGE: %s <TMD or WAD filename>\n",strArguments[0]);
    }
    return 0;
}
