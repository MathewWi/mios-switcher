#ifndef _SHOWBUFFERHEXDUMP_H_
#define _SHOWBUFFERHEXDUMP_H_
#include <stddef.h>
#include <stdbool.h>
void showBufferHexDump(unsigned char *chBuffer,size_t intBufferSize,bool blnDumpFormat);
#endif
