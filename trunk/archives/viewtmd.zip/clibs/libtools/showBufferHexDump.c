#include <stdio.h>
#include <ctype.h>
#include "showBufferHexDump.h"
void showBufferHexDump(unsigned char *chBuffer,size_t intBufferSize,bool blnDumpFormat) {
size_t i;
unsigned char chNewLine;
char strAsciiDump[16]={0};
    for (i=0;i<intBufferSize;i++) {
        strAsciiDump[15]=i%16;
        chNewLine=(strAsciiDump[15]==0)*blnDumpFormat;
        printf("%.*s%.*s",chNewLine," ",chNewLine*16,strAsciiDump);
        printf("%.*x %02x",8*printf("%.*s",chNewLine,"\n"),i*chNewLine,chBuffer[i]);
        strAsciiDump[(unsigned char) strAsciiDump[15]]=isprint(chBuffer[i])?chBuffer[i]:'.';
    }
}
