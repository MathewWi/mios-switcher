#ifndef _SWAPBYTES_H_
#define _SWAPBYTES_H_
#include <stddef.h>
unsigned char *swapBytes(unsigned char *chBytes,size_t intBytesCount);
#endif
