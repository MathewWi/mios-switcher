#ifndef _GETS64CMP_H_
#define _GETS64CMP_H_
#include <stddef.h>
int getS64Cmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
