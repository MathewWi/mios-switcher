#ifndef _GETU16CMP_H_
#define _GETU16CMP_H_
#include <stddef.h>
int getU16Cmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
