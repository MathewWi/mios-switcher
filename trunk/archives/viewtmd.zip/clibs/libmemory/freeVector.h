#ifndef _FREEVECTOR_H_
#define _FREEVECTOR_H_
void freeVector(void **varVector);
#endif
