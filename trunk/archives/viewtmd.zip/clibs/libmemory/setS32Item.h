#ifndef _SETS32ITEM_H_
#define _SETS32ITEM_H_
#include <stddef.h>
void *setS32Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
