#ifndef _GETDOUBLECMP_H_
#define _GETDOUBLECMP_H_
#include <stddef.h>
int getDoubleCmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
