#ifndef _GETPOINTERCMP_H_
#define _GETPOINTERCMP_H_
#include <stddef.h>
int getPointerCmp(const void *varPointer1,const void *varPointer2,size_t intMemorySize);
#endif
