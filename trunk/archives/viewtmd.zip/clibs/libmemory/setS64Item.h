#ifndef _SETS64ITEM_H_
#define _SETS64ITEM_H_
#include <stddef.h>
void *setS64Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
