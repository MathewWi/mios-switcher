#ifndef _SETFLOATITEM_H_
#define _SETFLOATITEM_H_
#include <stddef.h>
void *setFloatItem(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
