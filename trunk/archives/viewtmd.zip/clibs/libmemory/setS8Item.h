#ifndef _SETS8ITEM_H_
#define _SETS8ITEM_H_
#include <stddef.h>
void *setS8Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
