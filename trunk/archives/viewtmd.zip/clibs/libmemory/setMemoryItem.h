#ifndef _SETMEMORYITEM_H_
#define _SETMEMORYITEM_H_
#include <stddef.h>
void *setMemoryItem(void **varMemory,const void *varItem,size_t intMemorySize);
#endif
