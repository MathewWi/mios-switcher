#ifndef _GETMEMORYPOINTERITEM_H_
#define _GETMEMORYPOINTERITEM_H_
void *getMemoryPointerItem(const void *varMemoryItems,unsigned int intItemIndex,unsigned int intMemoryStepSize);
#endif
