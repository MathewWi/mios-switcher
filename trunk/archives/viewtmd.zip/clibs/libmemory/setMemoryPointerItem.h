#ifndef _SETMEMORYPOINTERITEM_H_
#define _SETMEMORYPOINTERITEM_H_
#include <stddef.h>
void *setMemoryPointerItem(void **varPointer,const void *varPointerItem,size_t intMemorySize);
#endif
