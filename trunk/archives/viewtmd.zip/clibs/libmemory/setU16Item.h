#ifndef _SETU16ITEM_H_
#define _SETU16ITEM_H_
#include <stddef.h>
void *setU16Item(void **varNumber,const void *varNumberItem,size_t intMemorySize);
#endif
