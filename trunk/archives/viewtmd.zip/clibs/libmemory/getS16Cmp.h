#ifndef _GETS16CMP_H_
#define _GETS16CMP_H_
#include <stddef.h>
int getS16Cmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
