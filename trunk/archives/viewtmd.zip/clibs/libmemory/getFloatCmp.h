#ifndef _GETFLOATCMP_H_
#define _GETFLOATCMP_H_
#include <stddef.h>
int getFloatCmp(const void *varNumber1,const void *varNumber2,size_t intMemorySize);
#endif
