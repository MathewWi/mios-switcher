#ifndef _GETBUFFERSHA1_H_
#define _GETBUFFERSHA1_H_
#include <stddef.h>
unsigned char *getBufferSha1(void *varBuffer,size_t intBufferSize,unsigned char *chHash);
#endif
