#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "../libshare/sha1.h"
#include "../macros.h"
#include "../libmemory/freeVector.h"
#include "getBufferSha1.h"
unsigned char *getBufferSha1(void *varBuffer,size_t intBufferSize,unsigned char *chHash) {
void *varAlignedBuffer=NULL;
    if (intBufferSize%16) {
        if ((varAlignedBuffer=calloc(ROUND_UP(intBufferSize,16),1))!=NULL) {
            memcpy(varAlignedBuffer,varBuffer,intBufferSize);
            SHA1((unsigned char *) varAlignedBuffer,intBufferSize,chHash);
            freeVector(&varAlignedBuffer);
        }
    }
    else {
        SHA1((unsigned char *) varBuffer,intBufferSize,chHash);
    }
    return chHash;
}
