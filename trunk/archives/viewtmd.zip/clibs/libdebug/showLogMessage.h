#ifndef _SHOWLOGMESSAGE_H_
#define _SHOWLOGMESSAGE_H_
void showLogMessage(int intLogMessage,const char *strSourceFilename,unsigned int intSourceLineNumber,const char *strLogMessage,...);
#endif
