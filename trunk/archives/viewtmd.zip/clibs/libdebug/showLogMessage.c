#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <time.h>
#include "libdebug.h"
//version finale
void showLogMessage(int intLogMessage,const char *strSourceFilename,unsigned int intSourceLineNumber,const char *strLogMessage,...) {
va_list pArguments;
time_t lngTime;
    if (intLogMessage) {
        if (intLogMessage>0) {
            lngTime=time(NULL);
            fprintf(stderr,"[%.24s] ",ctime(&lngTime));
        }
        switch(abs(intLogMessage)) {
            case DEBUG_LOG_MESSAGE:
                fprintf(stderr,"DEBUG: ");
                break;
            case INFO_LOG_MESSAGE:
                fprintf(stderr,"INFO: ");
                break;
            case WARNING_LOG_MESSAGE:
                fprintf(stderr,"WARNING: ");
                break;
            case ERROR_LOG_MESSAGE:
                fprintf(stderr,"ERROR: ");
                break;
            case SUCCESS_LOG_MESSAGE:
                fprintf(stderr,"SUCCESS: ");
                break;
            default:
                break;
        }
        va_start(pArguments,strLogMessage);
        vfprintf(stderr,strLogMessage,pArguments);
        va_end(pArguments);
        if (*strSourceFilename) {
            fprintf(stderr," |%s:%u",strSourceFilename,intSourceLineNumber);
        }
        fprintf(stderr,"\n");
    }
}
